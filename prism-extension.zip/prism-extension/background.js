// Prism service worker: the only part that talks to the network, and only to the
// Prism site the user configured, only to its read-only /api/ endpoints.
const DEFAULT_API = ''; // empty: the options page asks for the site address on first run

const ALLOWED = /^\/api\/(resolve|holders|dev|bundles|wallets)\?[A-Za-z0-9=&:,._-]{1,2400}$/;

async function apiBase() {
  const { apiBase: v } = await chrome.storage.sync.get('apiBase');
  return (v || DEFAULT_API || '').replace(/\/+$/, '');
}

chrome.runtime.onInstalled.addListener(async (d) => {
  if (d.reason === 'install' && !(await apiBase())) chrome.runtime.openOptionsPage();
});
chrome.action.onClicked.addListener(() => chrome.runtime.openOptionsPage());

chrome.runtime.onMessage.addListener((msg, _sender, reply) => {
  if (!msg || typeof msg !== 'object') return false;
  if (msg.type === 'options') { chrome.runtime.openOptionsPage(); reply({ ok: true }); return false; }
  if (msg.type === 'base') { apiBase().then((base) => reply({ base })); return true; }
  if (msg.type !== 'api') return false;
  (async () => {
    const base = await apiBase();
    if (!base) return reply({ status: 0, ok: false, body: null, error: 'no-site' });
    if (typeof msg.path !== 'string' || !ALLOWED.test(msg.path)) return reply({ status: 0, ok: false, body: null, error: 'blocked path' });
    const ac = new AbortController();
    const t = setTimeout(() => ac.abort(), 16000);
    try {
      const r = await fetch(base + msg.path, { headers: { accept: 'application/json' }, credentials: 'omit', signal: ac.signal });
      let body = null;
      try { body = await r.json(); } catch { body = null; }
      reply({ status: r.status, ok: r.ok, body });
    } catch (e) {
      reply({ status: 0, ok: false, body: null, error: 'unreachable' });
    } finally { clearTimeout(t); }
  })();
  return true;
});
