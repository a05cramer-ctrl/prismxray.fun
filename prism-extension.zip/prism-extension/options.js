const f = document.getElementById('f');
const input = document.getElementById('api');
const s = document.getElementById('s');
const say = (t, err) => { s.textContent = t; s.classList.toggle('err', !!err); };

chrome.storage.sync.get('apiBase').then(({ apiBase }) => { if (apiBase) { input.value = apiBase; say(`Connected to ${apiBase}`); } });

function normalise(v) {
  let u;
  try { u = new URL(v.trim().includes('://') ? v.trim() : `https://${v.trim()}`); } catch { return null; }
  if (u.protocol !== 'https:' && !/^(localhost|127\.0\.0\.1)$/.test(u.hostname)) return null;
  return u.origin;
}

f.addEventListener('submit', async (e) => {
  e.preventDefault();
  const origin = normalise(input.value);
  if (!origin) return say('That is not an https:// address.', true);
  // Ask only for this one origin (optional permission). The API also allows CORS, so
  // the panel keeps working if this is declined.
  try { await chrome.permissions.request({ origins: [`${origin}/*`] }); } catch { /* optional */ }
  say('Checking the site…');
  try {
    const r = await fetch(`${origin}/api/resolve?address=So11111111111111111111111111111111111111112`, { headers: { accept: 'application/json' } });
    const body = await r.json().catch(() => null);
    if (!body || typeof body !== 'object' || !('ok' in body)) { say(`${origin} answered, but not like a Prism site. Check the address.`, true); return; }
    await chrome.storage.sync.set({ apiBase: origin });
    input.value = origin;
    say(body.ok || r.status === 404 ? `Connected to ${origin}. Open a coin page.` : `Saved ${origin}. The site answered: ${body.error || r.status}`, !(body.ok || r.status === 404));
  } catch {
    say(`Couldn't reach ${origin}. Check the address and try again.`, true);
  }
});
