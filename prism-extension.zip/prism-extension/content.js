// Prism content script (built from src/ext-content.js + src/xray.js). Reads the page URL only.
(() => {
  // src/xray.js
  var ADDR = /[1-9A-HJ-NP-Za-km-z]{32,44}/g;
  function parseInput(text) {
    const s = String(text || "").trim();
    if (!s) return null;
    let path = s;
    try {
      const u = new URL(s);
      path = u.pathname + " " + u.search;
    } catch {
    }
    const found = path.match(ADDR) || [];
    return found.length ? found[found.length - 1] : null;
  }
  function addressFromPage(href) {
    let u;
    try {
      u = new URL(href);
    } catch {
      return null;
    }
    const h = u.hostname.replace(/^www\./, "");
    const seg = u.pathname.split("/").filter(Boolean);
    const pick = (x) => {
      const m = (x || "").match(ADDR);
      return m ? m[m.length - 1] : null;
    };
    if (h === "pump.fun" && seg[0] === "coin") return { address: pick(seg[1]), pair: false, site: "pump.fun" };
    if (h === "gmgn.ai" && seg[0] === "sol" && seg[1] === "token") return { address: pick(seg[2]), pair: false, site: "gmgn" };
    if (h === "axiom.trade" && seg[0] === "meme") return { address: pick(seg[1]), pair: true, site: "axiom" };
    if (h === "dexscreener.com" && seg[0] === "solana") return { address: pick(seg[1]), pair: true, site: "dexscreener" };
    return null;
  }
  var sleep = (ms) => new Promise((r) => setTimeout(r, ms));
  function createXray({ api, fetchJson }) {
    const base = String(api || "").replace(/\/+$/, "");
    const get = async (path) => {
      let r;
      try {
        r = await fetchJson(base + path);
      } catch (e) {
        return { error: "Prism API unreachable", offline: true };
      }
      if (!r || r.status === 0) return { error: "Prism API unreachable", offline: true };
      const b = r.body;
      if (!b || typeof b !== "object") return { error: `Prism API answered ${r.status} without data`, offline: r.status >= 404 || r.status === 0 };
      if (!r.ok || b.ok === false) return { error: b.error || `HTTP ${r.status}` };
      return { data: b };
    };
    let runId = 0;
    async function run(input, on) {
      const id = ++runId;
      const live = () => id === runId;
      const emit = (ev, ...a) => {
        if (live()) on(ev, ...a);
      };
      const address = parseInput(input);
      if (!address) {
        emit("invalid", "That is not a Solana address");
        return;
      }
      emit("start", address);
      const res = await get(`/api/resolve?address=${address}`);
      if (!live()) return;
      if (res.error) {
        emit(res.offline ? "offline" : "invalid", res.error);
        return;
      }
      const mint = res.data.mint;
      emit("mint", mint);
      const model = { mint, holders: null, dev: null, bundles: null, fresh: null, funding: null };
      const holdersP = get(`/api/holders?ca=${mint}`).then((r) => {
        model.holders = r.data || null;
        emit("block", "holders", r.data || null, r.error || null, model);
        return r.data;
      });
      const devP = get(`/api/dev?ca=${mint}`).then((r) => {
        model.dev = r.data || null;
        emit("block", "dev", r.data || null, r.error || null, model);
        return r.data;
      });
      await sleep(350);
      const bundlesP = get(`/api/bundles?ca=${mint}&slots=4`).then((r) => {
        model.bundles = r.data || null;
        emit("block", "bundles", r.data || null, r.error || null, model);
        return r.data;
      });
      const h = await holdersP;
      if (!live()) return;
      if (h && h.holders && h.holders.top20.length) {
        const w = h.holders.top20.map((x) => `${x.wallet}:${x.ta}`).join(",");
        const r = await get(`/api/wallets?mint=${mint}&w=${w}`);
        model.fresh = r.data || null;
        emit("block", "fresh", r.data || null, r.error || null, model);
      } else {
        emit("block", "fresh", null, h ? "no wallet holders to check" : "couldn't read holders", model);
      }
      const [b, d] = await Promise.all([bundlesP, devP]);
      if (!live()) return;
      const creator = b && b.creator || d && d.creator || h && h.curve && h.curve.creator || null;
      if (b && b.buyers && b.buyers.length) {
        const list = b.buyers.slice(0, 20).map((x) => x.wallet);
        const r = await get(`/api/wallets?mint=${mint}&w=${list.join(",")}${creator ? `&creator=${creator}` : ""}`);
        model.funding = r.data || null;
        emit("block", "funding", r.data || null, r.error || null, model);
      } else {
        emit("block", "funding", null, b ? "no early buyers to trace" : "couldn't read bundles", model);
      }
      emit("done", model);
    }
    return { run, cancel: () => {
      runId++;
    } };
  }
  var short = (a) => a ? `${a.slice(0, 4)}\u2026${a.slice(-4)}` : "";
  function pct(x, d) {
    if (x == null || !isFinite(x)) return "\u2014";
    if (x > 0 && x < 0.01) return "<0.01%";
    const dd = d ?? (x < 10 ? 2 : 1);
    return `${x.toFixed(dd)}%`;
  }
  function dur(s) {
    if (s == null) return "\u2014";
    if (s < 60) return `${Math.round(s)}s`;
    if (s < 3600) return `${Math.round(s / 60)}m`;
    if (s < 86400) {
      const h2 = Math.floor(s / 3600), m = Math.round(s % 3600 / 60);
      return m ? `${h2}h ${m}m` : `${h2}h`;
    }
    const d = Math.floor(s / 86400), h = Math.round(s % 86400 / 3600);
    return h ? `${d}d ${h}h` : `${d}d`;
  }
  var num = (n) => n == null ? "\u2014" : Number(n).toLocaleString("en-US");
  var LIMITS = { bundleExDev: 10, fresh: 25, top10: 35 };
  function blocks(model) {
    const out = {};
    const d = model.dev;
    if (d) {
      const c = d.counts || {};
      const cur = d.current;
      let thisCoin = null;
      if (cur) {
        thisCoin = `dev bought ${pct(cur.devBoughtPct)}`;
        thisCoin += cur.firstSellAfterSec == null ? " \xB7 no sells yet" : ` \xB7 sold ${pct(cur.devSoldPct)} \xB7 first after ${dur(cur.firstSellAfterSec)}`;
      }
      out.dev = {
        value: d.creator ? String(c.launches ?? 0) : "\u2014",
        unit: c.launches === 1 ? "earlier launch" : "earlier launches",
        flag: (c.dumpedWithinHour || 0) > 0 || !!(cur && cur.dumpedWithinHour),
        verdict: d.verdict,
        creator: d.creator,
        thisCoin,
        thisCoinFlag: !!(cur && cur.dumpedWithinHour),
        split: d.creator ? `${c.migrated || 0} migrated \xB7 ${c.trading || 0} trading \xB7 ${c.dead || 0} dead` : null,
        notes: d.notes || []
      };
    }
    const b = model.bundles;
    if (b) {
      if (!b.reached || !b.buyers) out.bundles = { value: "\u2014", unit: "bought in first slots", notes: b.notes || [], flag: false };
      else {
        const f = model.funding;
        const groups = f && f.groups || [];
        const shared = groups.filter((g) => !g.isDev).reduce((s, g) => s + g.wallets.length, 0);
        const devFunded = groups.filter((g) => g.isDev).reduce((s, g) => s + g.wallets.length, 0);
        let funding = null;
        if (f) {
          const parts = [];
          if (shared) parts.push(`${shared} share ${groups.filter((g) => !g.isDev).length === 1 ? "one funder" : "funders"}`);
          if (devFunded) parts.push(`${devFunded} funded by dev`);
          const traced = f.rows.filter((r) => r.funder).length;
          funding = parts.length ? parts.join(" \xB7 ") : `no shared funder among ${traced} traced`;
        }
        out.bundles = {
          value: pct(b.combinedPct, 1),
          unit: `bought in first ${b.slots} slots`,
          flag: b.exDevPct >= LIMITS.bundleExDev || shared > 0 || devFunded > 0,
          line: `${b.wallets} wallet${b.wallets === 1 ? "" : "s"} \xB7 dev ${pct(b.buyers.filter((x) => x.isDev).reduce((s, x) => s + x.pct, 0))} \xB7 others ${pct(b.exDevPct)}`,
          funding,
          fundingFlag: shared > 0 || devFunded > 0,
          buyers: b.buyers.slice(0, 6),
          notes: (b.notes || []).concat(f && f.notes || [])
        };
      }
    }
    const fr = model.fresh;
    if (fr) {
      const x = fr.fresh;
      out.fresh = {
        value: x.pct == null ? "\u2014" : pct(x.pct, 0),
        unit: "of top-20 holders fresh",
        flag: x.pct != null && x.pct >= LIMITS.fresh,
        line: `${x.fresh} of ${x.known} dated wallets funded <24h before buying${x.checked - x.known ? ` \xB7 ${x.checked - x.known} couldn't be dated` : ""}`,
        notes: fr.notes || []
      };
    }
    const h = model.holders;
    if (h) {
      if (!h.holders) out.top10 = { value: "\u2014", unit: "held by top 10", notes: h.notes || [], flag: false };
      else {
        const ex = h.holders.excluded.filter((e) => e.pct >= 0.01).map((e) => `${e.tag === "curve" ? "bonding curve" : e.tag === "burn" ? "burned" : "pool/program"} ${pct(e.pct, 1)}`);
        out.top10 = {
          value: pct(h.holders.top10Pct, 1),
          unit: "held by top 10 wallets",
          flag: h.holders.top10Pct >= LIMITS.top10,
          line: ex.length ? `excludes ${ex.slice(0, 2).join(" \xB7 ")}` : "no curve or pool balance to exclude",
          holders: `${num(h.holders.holderCount)}${h.holders.capped ? "+" : ""} holders read`,
          top: h.holders.top20.slice(0, 10).map((t) => t.pct),
          notes: h.notes || []
        };
      }
    }
    return out;
  }

  // extension/icons/icon32.png
  var icon32_default = "data:image/png;base64,iVBORw0KGgoAAAANSUhEUgAAACAAAAAgCAIAAAD8GO2jAAAKW0lEQVR42n1Wa1TUZR5+r//LzDDAzGAIamDiMIIQAYKX7qVoSWVl4VYmZXnU3Q9uu1p538KzWtq2VAcxu9gpu1hnj/fT1UBX21SIjjoIrApiDKgwzMz/9l72w2S7n/b59J73w/P7vec9zwWmp6cBCCGAAAAIAYQIIQQRxBBhQjDGGGNKKWNMURRN0xhjtm3ZtgMAUFWVUso5t22bM8Y455xzwQUXQggppZSSJGkBgAgl2SFCGGOEMSEEE0opoaZpTpkyZdXKlYRSy7IGBgb+3dV16vTpltbWrs4OKYGu647jQMdGDEEOOeAAQCE5EIDA34AQ/pUbUUIJIYRgRVFVVRWCBwL+cXl5AAAAQDAYnDp1KgDANM3vvvt2167PDx85jBByudyWaUIHQgAh5IxLIQX0+/0QQYwwQghjTDDGlCqUKIoKIbRtGwCg6zohZOTILAihNyUlY0RGTk7OjcXFZeXlqqoCAHbv2f3aa3+72N2t6bphGA5zHIdxxjjnMCMjACHCBBNMktA0DWFkmWZaWnrRxKKKyopQKBQIBCCEjY3b9u3bhzECAFiWFQqFqqurH3roIY/H09fXt2b16m+++dbldhmG4TiO4ziMMZyS4sEYE0IopYqiuFwu27Y1VZs3b97KlSvnz59fUlIyevRov9/v8/ni8ZjH41q69PenTp3a2th48MCBPXv3NB9uzrn++mAwf0ZVVU9Pd1vbzy63SwghhZAAYG+qlxBCKaGU6i6XYRjlZWUbN2588MEHfT5fb2/vl19+uXVrQyTSN3FiUdvPbc3Nh+Px+Nmz7UjK9jOn4tHB6ODg7t27MaHl5eV33HFnZ2dHe7hd01TGuQSSYJRcX9FdeiwWm/vw3NWrV6uqev78+e3bt3/99deJRELTtAkTJiCEIIBSSoyxYIxzZsditQuebjt53JOa1t4efvvtxqeeWvjSSy93dHReuHBeVVUhBSIYE0J0XTcM4+GHHn755ZdVVT1w4MDjjz++67PPbr755vfee//IkSMLFz4DABBC5ObmVkyapFJyx623j3Srk0tLstNSc64bUV5a8torm44cOZyamrpixQoIEaWUYIIDGRm6rjmOXV4+afPmzRjj999//4UXns/JzXnzzbdqamoGBvq3bdvWe+lSYUHB2fb2Tz/9NHz6dORid0frSV98UP/nQedSd3vkcuupM6ZpnfzppxkzqkKhUDgcPnPmjKIoiBCCEHa5XC+++KKiKAcOHFi7dm1l5eSPPvzI6/UuWLDgySef3L59e1dnJwAgOjx89913r12/NjMz8/UdH+aOzHw8OLLCSx5ZUPuH5c87lnnhwvlPPvkEAFBTU5P0AaIoimEYtbW1wWCwu7t7/V/WFxQWNDQ0nDhxYsmSJbZt+/w+IYSiKACA1NTUPXv2NDd9P9QfWTjnfk/8yquXlSgTXW/9fYATouuqpu/fv/938+aVl5dPKCho+6kNAQB8Pl9NTQ0AYOvWhr6+vk2bXhkYGFi06FnLtlxul2M7lmUJwQEAw8PRWbNm1W3Y4Bsxov6DDw1v+swtb+PyW2+5f+7SP68Ynx/6/It/RPoj3zd9jzGurKiwbIuYpllZWTlmzJi+vr49e/ZVz67ODwYfe+yxaHQ4LS3NMAxNVTnnQkgAgMvl/uGHHyKRSCyRWLVmdc/V2JbNm7vPn9dOn01JP3Gpr2/9+nXMdlpaWu+5597CwomUECSlLC0tlVI2NTUNDl6tra1tbW1tbm5yu92GYfBfBc+klAAAxlheXt5tt93m8weqq+/TU9Nuu+uu0WPHFZeVTZ4yNT3dN7NqZoo3taOjAwBwww03eDwepChKfn4+hPDHH3/MyMgoLCzcu3evZdmC/y8E5zzpbkNDQ9GhoVgsZlp2wrSGhuPDiUQsnhiKRuPxeCKRsG2rv7/fNM1AIOByuZGmaYFAAABw8eLFkSMzIYThcBhjzDiXUgohhBCMMQgh57yoqCgvL+/K1av33/9AOBx+9NFHL1++XFZWmp2djTGumjGjs7OzvLzcsizDSCiKous6IZRompY0L6/XCwAYGhpCCCXZIYSMc8aZFAJjXFJSUlJSAv4vTNOYO/cRAKDL5WLMIYKLpCcrqpI8aJompQQQSCCllMxxNFXbu2/fdZmZmq5JKQn+b4oIITwpnqoZVUePHo30R6pnV3MuEonExo1/TU1N7em5SBKJRCQSyc/PH5U9qqmpSUoZCoUOHToE4a8TuOQY40gksm7duqTpUoUSTJIebBhGWVnZvffcu21b49Wrg3MemBPpj9iO8/kXX1impagKsm27s7NTSllQUNDb29vR2VFVVQUAQBAlnyyl5JxDCFNSUlJSUjwej8ftScLr9WqaNrOqyrKsCxe6KysrAQBdnV1Dg4PeFK/H4+GMIwhhS0sLhHDatGkpnpSdOz+uqKgoLS2Nx+OUUghhckwy2S3TMi3TNE3DNGzbHh4e9ng8s6ur9+7dG4n0TZs2DQBw7NhR0zQZY7Ztc86RpmvHTxzv7e3Nzc2ddc+snR991NPTs2HDBoSQBJJSihBKjpFSCikEF4wzwQXn/MqVK8uWLaOUNjQ0hEITJk2a5DhOc/NhQohlWYwxLjiCAPZHIrt27QIAPL3waUWhz/3puYkTJ77xxhu2bdu2rWkaoSRZBpLACDuO098fWbp06ezZs+vq6s6dO7do0SJVVb/66qtwOEwIcRwnKR+cnp6uqlpXV9f06dNzrs/xer3vvvvupUuXlixZMmXylJMnT/b0dAshEUIAAiGEY9vxeNzv99XVbZg/f/7rr79eX1+/cOHCJ554Ih6PLV++/OrgoOA8Gcicc5yWlkYpjcVi586dmzlzZnFxMaW0sXFrS0vr3LlzFy9ePD4vmIwaTdX8fn9hYeGzzzzzyiuvBoPBNWvW1NfXz3lgzqpVqyilW7ZsOXjwoKqqpmky5jDOpJAgNzc3GAyWlNw4fvz4TRs3JevYO++8U1AwoaysrL6+/pdffkle/lbWotHojh07brnllrFjx9bV1RmGIaX8+OOPQ6FQcXFxXl5eTk5Odnb2iBEjAoEAHDNmNKFUVVRd1y3TrH2qdtmyPwIAWlpaGhoavv3mG4jg+PHBvLw8t9sdj8cudHeHw+HoUPSmkpsWL1l85513AgB27ty5ft06qiiO45im6TgOZ5xxJoSAWVlZhBKFKoqiaLoWj8VnzJi+fPmKrKwsAMDx4z8eOnSore3nixd7DSNOKA34A0VFRbfffvvUqVMhhNHhaH39Gx/s2EEptR3btm3mMIc5nPHki2Fm5nUYk98kqmu6aZpZ2Vnz5s27r7ra5/P/ZjKWbVGqoGvKsCxr//79jdsa28Ptbrfbtm3LtpjDkn8rrhVgmJGRgRAi10ApVTUVSGDb9qhRoyZPnlJWVjpu3LiMERm6pjuOc+XKlc6OzmP/Onb06LGOs2cRQoRSyzTZNXCe3F0IIYWU0O/3J1spxhgjnGy9yZYnuDAtC2Pk8bi9Xi+lim3b8Xh8KDpkmZaiKIqiMIfZzGHM4exadIj/dncp5X8A5MCP51ZyMiMAAAAASUVORK5CYII=";

  // src/ext-content.js
  var ask = (msg) => new Promise((res) => {
    try {
      chrome.runtime.sendMessage(msg, (r) => {
        void chrome.runtime.lastError;
        res(r || { status: 0, ok: false, body: null });
      });
    } catch {
      res({ status: 0, ok: false, body: null });
    }
  });
  var xray = createXray({ api: "", fetchJson: (path) => ask({ type: "api", path }) });
  var CSS = `
:host { all: initial; }
* { box-sizing: border-box; }
[hidden] { display: none !important; }
.p { position: fixed; z-index: 2147483646; width: 288px; font: 13px/1.45 ui-sans-serif, system-ui, -apple-system, "Segoe UI", sans-serif; color: #f4f3f0;
  background: #0e0e10; border: 1px solid rgba(255,255,255,.14); border-radius: 14px; box-shadow: 0 24px 60px rgba(0,0,0,.55); overflow: hidden; }
.h { display: flex; align-items: center; gap: 8px; padding: 10px 10px 10px 12px; cursor: grab; user-select: none; touch-action: none; border-bottom: 1px solid rgba(255,255,255,.08); }
.h:active { cursor: grabbing; }
.h img { width: 20px; height: 20px; border-radius: 5px; }
.h b { font-weight: 650; letter-spacing: -.02em; }
.h .sym { font: 11px ui-monospace, Menlo, monospace; color: rgba(244,243,240,.6); overflow: hidden; text-overflow: ellipsis; white-space: nowrap; max-width: 110px; }
.h .sp { flex: 1; }
.ib { width: 26px; height: 26px; display: grid; place-items: center; border-radius: 7px; border: 0; background: transparent; color: rgba(244,243,240,.6); cursor: pointer; font: 15px/1 ui-monospace, monospace; }
.ib:hover { background: rgba(255,255,255,.08); color: #f4f3f0; }
.b { padding: 10px 12px 12px; }
.v { font: 12px/1.45 ui-monospace, Menlo, monospace; letter-spacing: -.01em; padding-bottom: 10px; margin-bottom: 10px; border-bottom: 1px solid rgba(255,255,255,.08); min-height: 28px; }
.v small { display: block; color: rgba(244,243,240,.45); font-size: 10.5px; margin-top: 2px; }
.g { display: grid; grid-template-columns: 1fr 1fr; gap: 6px; }
.c { background: #151517; border: 1px solid rgba(255,255,255,.08); border-radius: 9px; padding: 8px 9px 9px; min-height: 66px; }
.c.f { border-color: rgba(255,74,28,.5); }
.c p { margin: 0; font: 9.5px/1.2 ui-monospace, Menlo, monospace; letter-spacing: .08em; text-transform: uppercase; color: rgba(244,243,240,.45); }
.c strong { display: block; margin-top: 5px; font: 500 19px/1 ui-monospace, Menlo, monospace; letter-spacing: -.05em; }
.c.f strong, .e { color: #ff4a1c; }
.c span { display: block; margin-top: 4px; font-size: 10.5px; line-height: 1.3; color: rgba(244,243,240,.55); }
.sk { display: block; height: 14px; margin-top: 7px; width: 60%; border-radius: 3px; background: linear-gradient(90deg, rgba(255,255,255,.06), rgba(255,255,255,.16), rgba(255,255,255,.06)); background-size: 200% 100%; animation: s 1.3s linear infinite; }
.sk.l { width: 90%; height: 10px; }
@keyframes s { to { background-position: -200% 0; } }
.ft { display: flex; justify-content: space-between; align-items: center; margin-top: 10px; font: 10.5px ui-monospace, Menlo, monospace; color: rgba(244,243,240,.45); }
.ft a { color: #f4f3f0; text-decoration: none; }
.ft a:hover { text-decoration: underline; }
.msg { font-size: 12.5px; color: rgba(244,243,240,.7); margin: 0 0 10px; }
.btn { display: inline-block; padding: 8px 12px; border-radius: 9px; background: #f4f3f0; color: #0b0b0c; font-weight: 650; border: 0; cursor: pointer; font-size: 12.5px; }
.mini { position: fixed; z-index: 2147483646; width: 46px; height: 46px; border-radius: 50%; border: 1px solid rgba(255,255,255,.18); background: #0e0e10 center/150% no-repeat; cursor: pointer; box-shadow: 0 12px 30px rgba(0,0,0,.5); padding: 0; }
.mini.f::after { content: ''; position: absolute; right: 3px; top: 3px; width: 9px; height: 9px; border-radius: 50%; background: #ff4a1c; box-shadow: 0 0 8px #ff4a1c; }
@media (prefers-reduced-motion: reduce) { .sk { animation: none; } }
`;
  var host;
  var root;
  var panel;
  var mini;
  var state = { x: null, y: null, min: false };
  var current = null;
  var closedFor = null;
  var lastHref = "";
  function load() {
    return new Promise((r) => chrome.storage.local.get("prismPanel", (v) => r(v && v.prismPanel || {})));
  }
  var save = () => chrome.storage.local.set({ prismPanel: state.auto ? { min: state.min } : { x: state.x, y: state.y, min: state.min } });
  function clampPos() {
    const w = state.min ? 46 : 288, h = state.min ? 46 : panel ? panel.offsetHeight || 300 : 300;
    if (state.x == null || state.auto) {
      state.auto = true;
      state.x = innerWidth - w - 18;
      state.y = innerHeight - h - 18;
    }
    state.x = Math.max(6, Math.min(innerWidth - w - 6, state.x));
    state.y = Math.max(6, Math.min(innerHeight - h - 6, state.y));
  }
  function place() {
    clampPos();
    for (const el of [panel, mini]) {
      el.style.left = `${state.x}px`;
      el.style.top = `${state.y}px`;
    }
  }
  function build() {
    host = document.createElement("div");
    host.setAttribute("data-prism", "");
    root = host.attachShadow({ mode: "closed" });
    root.innerHTML = `<style>${CSS}</style>
  <section class="p" role="dialog" aria-label="Prism x-ray">
    <div class="h"><img src="${icon32_default}" alt=""><b>Prism</b><span class="sym"></span><span class="sp"></span>
      <button class="ib" data-a="min" aria-label="Fold panel" title="Fold">\u2013</button><button class="ib" data-a="close" aria-label="Close panel" title="Close">\xD7</button></div>
    <div class="b"></div>
  </section>
  <button class="mini" aria-label="Open Prism x-ray" style="background-image:url(${icon32_default})"></button>`;
    panel = root.querySelector(".p");
    mini = root.querySelector(".mini");
    document.documentElement.appendChild(host);
    root.querySelector("[data-a=min]").addEventListener("click", () => {
      state.min = true;
      show();
      save();
    });
    root.querySelector("[data-a=close]").addEventListener("click", () => {
      closedFor = location.href;
      host.remove();
      host = null;
    });
    mini.addEventListener("click", (e) => {
      if (mini.dataset.dragged) {
        delete mini.dataset.dragged;
        return;
      }
      state.min = false;
      show();
      save();
    });
    drag(root.querySelector(".h"));
    drag(mini, true);
    addEventListener("resize", place);
  }
  function drag(handle, isMini) {
    let sx, sy, ox, oy, moved;
    handle.addEventListener("pointerdown", (e) => {
      if (e.target.closest(".ib")) return;
      sx = e.clientX;
      sy = e.clientY;
      ox = state.x;
      oy = state.y;
      moved = false;
      handle.setPointerCapture(e.pointerId);
    });
    handle.addEventListener("pointermove", (e) => {
      if (sx == null) return;
      const dx = e.clientX - sx, dy = e.clientY - sy;
      if (Math.abs(dx) + Math.abs(dy) > 3) moved = true;
      state.auto = false;
      state.x = ox + dx;
      state.y = oy + dy;
      place();
    });
    const end = () => {
      if (sx == null) return;
      sx = null;
      if (moved) {
        save();
        if (isMini) mini.dataset.dragged = "1";
      }
    };
    handle.addEventListener("pointerup", end);
    handle.addEventListener("pointercancel", end);
  }
  function show() {
    panel.hidden = state.min;
    mini.hidden = !state.min;
    place();
  }
  var body = () => root.querySelector(".b");
  var esc = (s) => String(s ?? "").replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" })[c]);
  var cell = (label, x, sub) => {
    if (x === void 0) return `<div class="c"><p>${label}</p><span class="sk"></span><span class="sk l"></span></div>`;
    if (x === null) return `<div class="c"><p>${label}</p><strong>\u2014</strong><span class="e">${esc(sub || "couldn't read")}</span></div>`;
    return `<div class="c${x.flag ? " f" : ""}"><p>${label}</p><strong>${esc(x.value)}</strong><span>${esc(sub ?? x.unit)}</span></div>`;
  };
  var view = {};
  function render(mint, base) {
    const b = view.model ? blocks(view.model) : {};
    const st = view.status || {};
    const dev = st.dev === "err" ? null : b.dev;
    const bun = st.bundles === "err" ? null : b.bundles;
    const fr = st.fresh === "err" ? null : b.fresh;
    const top = st.holders === "err" ? null : b.top10;
    const verdict = view.offline ? `<span class="e">couldn't reach the Prism site</span><small>check the address in Prism settings</small>` : b.dev && b.dev.verdict ? `<span class="${b.dev.flag ? "e" : ""}">${esc(b.dev.verdict)}</span><small>creator ${esc(short(b.dev.creator))}${b.dev.thisCoin ? ` \xB7 ${esc(b.dev.thisCoin)}` : ""}</small>` : st.dev === "err" ? `<span class="e">couldn't read dev history</span><small>${esc(view.errors.dev || "")}</small>` : '<span class="sk l"></span><span class="sk"></span>';
    const flagged = [dev, bun, fr, top].some((x) => x && x.flag);
    mini.classList.toggle("f", flagged);
    const blk = (label, key, data, sub) => {
      if (view.offline) return cell(label, null, "offline");
      if (st[key] === "err") return cell(label, null, view.errors[key]);
      if (data && data.value === "\u2014") return cell(label, null, (data.notes || [])[0] || "couldn't read");
      return data ? cell(label, data, sub) : cell(label, void 0);
    };
    body().innerHTML = `
    <div class="v">${verdict}</div>
    <div class="g">
      ${blk("dev", "dev", dev, dev && (dev.flag ? `${dev.unit} \xB7 dumps` : dev.unit))}
      ${blk("bundles", "bundles", bun, bun && (bun.funding || "first 4 slots"))}
      ${blk("fresh", "fresh", fr, "of top 20 holders")}
      ${blk("top 10", "holders", top, "wallets, excl. curve")}
    </div>
    <div class="ft"><span>${esc(short(mint))}</span>${base ? `<a href="${esc(base)}/?ca=${esc(mint)}" target="_blank" rel="noopener">full x-ray \u2192</a>` : ""}</div>`;
    place();
  }
  function needsSite() {
    body().innerHTML = `<p class="msg">Prism needs its site address once to read live data.</p><button class="btn" type="button">Open Prism settings</button>`;
    body().querySelector(".btn").addEventListener("click", () => ask({ type: "options" }));
  }
  async function scan(found) {
    const { base } = await ask({ type: "base" });
    if (!host) build();
    show();
    root.querySelector(".sym").textContent = "";
    if (!base) {
      needsSite();
      return;
    }
    view = { model: null, status: {}, errors: {}, mint: found.address };
    render(found.address, base);
    xray.run(found.address, (ev, ...a) => {
      if (ev === "offline") {
        view.offline = true;
        render(view.mint, base);
        return;
      }
      if (ev === "invalid") {
        body().innerHTML = `<p class="msg e">${esc(a[0])}</p>`;
        return;
      }
      if (ev === "mint") {
        view.mint = a[0];
        render(view.mint, base);
        return;
      }
      if (ev === "block") {
        const [k, data, err, m] = a;
        view.model = m;
        const key = k === "funding" ? "bundles" : k;
        if (err && k !== "funding") {
          view.status[key] = "err";
          view.errors[key] = err;
        }
        if (k === "holders" && data && data.token && data.token.symbol) root.querySelector(".sym").textContent = `$${data.token.symbol}`;
        render(view.mint, base);
      }
    });
  }
  function check() {
    const href = location.href;
    if (href === lastHref) return;
    lastHref = href;
    const found = addressFromPage(href);
    if (!found || !found.address) {
      if (host) host.style.display = "none";
      xray.cancel();
      current = null;
      return;
    }
    if (closedFor === href) return;
    if (host) host.style.display = "";
    if (current === found.address) return;
    current = found.address;
    scan(found);
  }
  load().then((s) => {
    state = { x: s.x ?? null, y: s.y ?? null, min: !!s.min };
    check();
    setInterval(check, 800);
    addEventListener("popstate", check);
  });
})();
